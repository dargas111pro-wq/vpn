const tg = window.Telegram && Telegram.WebApp;
if (tg) { tg.ready(); tg.expand(); try{tg.setHeaderColor('#000000');tg.setBackgroundColor('#050b0c');}catch(e){} }
const user = (tg && tg.initDataUnsafe && tg.initDataUnsafe.user) || {id: 123456, username: 'username'};

// ---- CONFIG (поменяйте под себя) ----
const BOT_USERNAME = 'DefendVPN_bot';
const SITE_URL     = 'https://example.com/mini-app/';
const SUPPORT_URL  = 'https://t.me/your_support';

const $ = id => document.getElementById(id);
function toast(t){const e=$('toast');e.textContent=t;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>e.style.display='none',1800)}
function openUrl(u){ (tg && tg.openLink) ? tg.openLink(u) : window.open(u,'_blank') }

// navigation
let current='home';
function go(name){
  current=name;
  document.querySelectorAll('.screen').forEach(s=>{s.classList.remove('active');s.style.display=''});
  const el=$('s-'+name); el.classList.add('active');
  if(name==='chat') el.style.display='flex';
  const navKey = name==='chat' ? 'sup' : name;
  document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.s===navKey));
  if(tg){ try{ (name==='home')?tg.BackButton.hide():tg.BackButton.show() }catch(e){} }
}
if(tg){ try{ tg.BackButton.onClick(()=>go('home')) }catch(e){} }

// VPN toggle
let vpnOn=false;
function toggleVpn(){
  vpnOn=!vpnOn;
  $('power').classList.toggle('on',vpnOn);
  $('statusTxt').textContent=vpnOn?'Подключено':'Не подключено';
  $('hint').textContent=vpnOn?'DefendVPN защищает ваше соединение':'Нажмите, чтобы подключиться';
  if(tg&&tg.HapticFeedback) tg.HapticFeedback.impactOccurred('medium');
}

// referral
let tab='site';
function refUrl(){ return tab==='site' ? `${SITE_URL}?ref=${user.id}` : `https://t.me/${BOT_USERNAME}?start=ref_${user.id}` }
function setTab(t){tab=t;$('tabSite').classList.toggle('on',t==='site');$('tabTg').classList.toggle('on',t==='tg');$('refLink').textContent=refUrl()}
function copyLink(){
  const u=refUrl();
  (navigator.clipboard?navigator.clipboard.writeText(u):Promise.reject()).then(()=>toast('Ссылка скопирована'))
   .catch(()=>{const a=document.createElement('textarea');a.value=u;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();toast('Ссылка скопирована')});
}

// FAQ
const FAQ=[
 ['VPN не подключается','Проверьте подключение к интернету и попробуйте сменить локацию. Если проблема сохраняется - перезапустите приложение'],
 ['Как установить VPN?','Откройте раздел "Настройка VPN" скачайте приложение и импортируйте ключ доступа'],
 ['Интернет стал медленнее','Скорость может зависеть от выбранной локации. Попробуйте подключиться к ближайшему серверу'],
 ['Нашли баг или ошибку?','Опишите проблему в чате поддержки — мы постараемся помочь как можно быстрее']
];
function openFaq(i){$('mTitle').textContent=FAQ[i][0];$('mText').textContent=FAQ[i][1];$('overlay').classList.add('open')}
function closeFaq(){$('overlay').classList.remove('open')}

// chat (локально; для реальной связи отправляйте сообщения боту через tg.sendData или свой API)
function addMsg(text,who){
  $('welcome').style.display='none';
  const d=document.createElement('div');d.className='msg '+who;d.textContent=text;
  $('msgs').appendChild(d);$('msgs').scrollTop=$('msgs').scrollHeight;
}
function sendMsg(){
  const v=$('chatIn').value.trim(); if(!v) return;
  addMsg(v,'me'); $('chatIn').value='';
  if(tg){ try{ tg.sendData(JSON.stringify({type:'support',text:v})) }catch(e){} }
  setTimeout(()=>addMsg('Спасибо! Менеджер скоро ответит вам.','bot'),700);
}
function quick(el){ $('chatIn').value=el.textContent; sendMsg() }

// init
$('tgName').textContent='@'+(user.username||('id'+user.id));
$('today').textContent=new Date().toLocaleDateString('ru-RU');
setTab('site');
