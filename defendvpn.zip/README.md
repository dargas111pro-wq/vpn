# DefendVPN — Telegram Mini App

Мини-приложение для Telegram-бота: главная, реферальная программа, поддержка с чатом и настройки.

## Файлы
- `index.html` — разметка
- `style.css` — стили
- `app.js` — логика (настройки в блоке `CONFIG` в начале файла)

## Настройка
В `app.js` измени:
```js
const BOT_USERNAME = 'DefendVPN_bot';
const SITE_URL     = 'https://example.com/mini-app/';
const SUPPORT_URL  = 'https://t.me/your_support';
```

## Публикация на GitHub Pages
1. Создай репозиторий и загрузи все файлы в корень (включая `.nojekyll`).
2. **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `(root)` → Save.**
3. Через минуту сайт будет доступен по адресу `https://<username>.github.io/<repo>/`.

## Подключение к боту
Ссылку из шага 3 укажи как Web App:
- в @BotFather: `/mybots` → бот → **Bot Settings → Menu Button** → вставить URL, или
- кнопкой `web_app` в inline/reply-клавиатуре бота.
